from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import logout,login
from django.contrib.auth import authenticate



# Create your views here.
# username = vinayak pass= vinu12345678
def index(request):
    # return HttpResponse("home page is here")
    if request.user.is_anonymous:
        return redirect("/login")
    return render(request,'index.html')

def loginuser(request):
    if request.method =="POST":
        username =request.POST.get("username")
        password =request.POST.get("password")
        # check if user has user has entered correct credentials
        user = authenticate(username=username, password=password)
        if user is not None:
            # A backend authentication credentials
            login(request,user)
            return redirect("/")
        else:
            # No backend authentication the credentials
            return render(request,'login.html')
    return render(request,'login.html')
    

def logoutuser(request):
    logout(request)
    return redirect("/login")
